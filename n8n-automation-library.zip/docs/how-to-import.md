# Como importar workflows no n8n

1. Abra o painel do n8n  
2. Clique em **Import > From File**  
3. Selecione o arquivo `.json` do workflow desejado  
4. Configure suas credenciais (API Keys, logins, etc)  
5. Salve e execute 🚀
