# Boas práticas de segurança

- Nunca compartilhe suas credenciais diretamente no workflow  
- Use variáveis de ambiente no n8n (`{{ $env.VARIABLE }}`)  
- Sempre teste em ambiente seguro antes de colocar em produção  
